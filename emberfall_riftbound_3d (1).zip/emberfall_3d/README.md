# Emberfall: Riftbound — True 3D Browser Prototype

## Replace the old game on GitHub Pages
1. Extract this ZIP on your iPad using the Files app.
2. Open your existing `emberfall-riftbound` repository on GitHub.
3. Tap **Add file → Upload files** and choose the new `index.html` from this folder.
4. If GitHub says the file already exists, use the repository file list to open the old `index.html`, tap the pencil/Edit option or `...` menu, and replace its contents with the new file contents; alternatively delete the old file, commit the deletion, then upload this new `index.html` and commit it.
5. Ensure **Settings → Pages** still says deploy from branch `main`, folder `/(root)`.
6. Wait a few minutes and reload your existing Pages website.

## Controls
Desktop: WASD/arrows move; Space strike; E Arc Burst; Shift dash; drag the 3D scene to orbit the camera.

iPad: left virtual joystick moves; Strike, Arc Burst and Dash buttons attack; drag the 3D scene to orbit the camera.

## Note
Uses real Three.js 3D geometry, loaded from jsDelivr CDN. An internet connection is needed. Character models are assembled from 3D primitives in this prototype.
